# ADP 多Agent协同 MCP 服务

## 📋 项目简介

这是一个基于 MCP 协议的多Agent协同服务，能够：
- 🔍 自动识别用户问题涉及的领域
- ✂️ 将复杂问题拆解为多个子问题
- 🚀 并行调用多个专业 Agent
- 📝 整合答案返回统一结果

## 🏗️ 架构设计

```
用户提问
    ↓
【意图识别与拆解层】
    ↓
【路由分发层】(并行调用)
    ├─ 财务Agent
    ├─ 人力Agent
    └─ 研发Agent
    ↓
【结果汇总层】
    ↓
返回统一答复
```

## 📦 项目结构

```
adp-mcp-orchestrator/
├── index.py              # 云函数入口
├── orchestrator.py       # 核心编排逻辑
├── agents_config.py      # Agent配置
├── requirements.txt      # 依赖
├── serverless.yml        # 部署配置
└── README.md            # 说明文档
```

## 🚀 部署步骤

### 方式一：通过腾讯云控制台部署

1. **准备代码包**
   ```bash
   cd adp-mcp-orchestrator
   zip -r function.zip .
   ```

2. **登录腾讯云控制台**
   - 访问 https://console.cloud.tencent.com/scf
   - 创建函数

3. **配置函数**
   - 函数名称：`adp-mcp-orchestrator`
   - 运行环境：`Python 3.9`
   - 上传代码包：`function.zip`
   - 执行方法：`index.main_handler`
   - 内存：512MB
   - 超时时间：30秒

4. **配置触发器**
   - 触发方式：`API网关`
   - 请求方法：`POST`
   - 发布环境：`发布`
   - 勾选"启用集成响应"

5. **获取访问地址**
   - 复制 API 网关的访问 URL
   - 格式：`https://service-xxx.gz.apigw.tencentcs.com/release/mcp`

### 方式二：通过 Serverless Framework 部署

1. **安装 Serverless Framework**
   ```bash
   npm install -g serverless
   ```

2. **配置腾讯云密钥**
   ```bash
   serverless credentials set \
     --provider tencent \
     --key YOUR_SECRET_ID \
     --secret YOUR_SECRET_KEY
   ```

3. **部署**
   ```bash
   cd adp-mcp-orchestrator
   serverless deploy
   ```

4. **查看部署结果**
   - 部署成功后会显示 API 网关地址

## ⚙️ 配置说明

### 修改 Agent 配置

编辑 `agents_config.py`，替换为实际的 ADP 应用ID：

```python
AGENTS = {
    "finance": {
        "name": "财务Agent",
        "description": "处理财务、经营、成本、预算、报销等问题",
        "app_id": "your-actual-finance-app-id"
    },
    "hr": {
        "name": "人力Agent",
        "description": "处理人员、招聘、考勤、薪资、绩效等问题",
        "app_id": "your-actual-hr-app-id"
    },
    "dev": {
        "name": "研发Agent",
        "description": "处理项目进度、技术方案、代码、bug等问题",
        "app_id": "your-actual-dev-app-id"
    }
}
```

## 🔗 在 Knot 中配置

### 方式一：通过 MCP 直接配置

```json
{
  "mcpServers": {
    "adp-orchestrator": {
      "url": "https://your-cloud-function-url/mcp",
      "transportType": "http",
      "headers": {
        "Content-Type": "application/json"
      },
      "timeout": 60000
    }
  }
}
```

### 方式二：通过 Skill 配置（推荐）

创建一个 Skill 文件，让主 Agent 知道如何使用这个 MCP：

**multi-agent-skill.md**
```markdown
# 多Agent协同对话技能

## 何时使用

当用户的问题涉及多个领域（财务、人力、研发等）时，使用此技能。

## 使用方法

调用 MCP 工具 `multi_agent_chat`，传入以下参数：
- question: 用户的完整问题
- app_key: ADP AppKey（从用户处获取或使用默认值）

## 示例

用户问："公司的经营情况怎么样？公司有多少人？研发的进度怎么样？"

调用：
```json
{
  "tool": "multi_agent_chat",
  "arguments": {
    "question": "公司的经营情况怎么样？公司有多少人？研发的进度怎么样？",
    "app_key": "user-provided-app-key"
  }
}
```

系统会：
1. 自动拆解为3个子问题
2. 分别调用财务、人力、研发Agent
3. 整合答案返回
```

## 🧪 测试

### 本地测试

```bash
# 模拟云函数调用
python -c "
import json
from index import main_handler

event = {
    'body': json.dumps({
        'method': 'tools/list'
    })
}

result = main_handler(event, None)
print(json.dumps(result, indent=2, ensure_ascii=False))
"
```

### API 测试

```bash
curl -X POST https://your-cloud-function-url/mcp \
  -H "Content-Type: application/json" \
  -d '{
    "method": "tools/call",
    "params": {
      "name": "multi_agent_chat",
      "arguments": {
        "question": "公司的经营情况怎么样？",
        "app_key": "your-app-key"
      }
    }
  }'
```

## 📊 监控与日志

在腾讯云控制台查看：
- 调用次数
- 错误率
- 执行时长
- 详细日志

## 💡 最佳实践

1. **AppKey 管理**
   - 建议让用户在调用时提供 AppKey
   - 也可以配置默认 AppKey

2. **超时控制**
   - 云函数超时时间建议设置为 30-60 秒
   - 单个 Agent 调用超时设置为 60 秒

3. **错误处理**
   - 单个 Agent 失败不影响其他 Agent
   - 最终汇总时会标注失败信息

4. **成本优化**
   - 腾讯云函数每月 100 万次免费调用
   - 并行调用可减少总耗时

## 🔧 故障排查

### 问题1：部署失败
- 检查 `requirements.txt` 是否正确
- 确认运行环境为 Python 3.9

### 问题2：调用超时
- 增加云函数超时时间
- 检查 Agent 响应速度

### 问题3：Agent 调用失败
- 确认 `agents_config.py` 中的 app_id 正确
- 检查 AppKey 是否有效

## 📝 更新日志

### v1.0.0 (2026-02-15)
- ✅ 初始版本
- ✅ 支持问题拆解
- ✅ 支持并行调用
- ✅ 支持结果汇总

## 📄 许可证

MIT License
